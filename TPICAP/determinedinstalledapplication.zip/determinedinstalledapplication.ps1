#$servers = Get-Content C:\temp\cmdbservers.txt
$servers = 'LDN1WS9724'
$output = @()

function set-credential {
    param (
        $computername
    )

    $FQDN = [net.dns]::GetHostEntry($computername).Hostname
    $FQDNfinal = $FQDN.Split( "." )[1]
    switch -Wildcard ($FQDNfinal) {
        "corp" {
            $AccountName = "corp.ad.tullib.com\CORP PMS"
            $accontPassword = ConvertTo-SecureString -String "cO0Ja^&XGzIRjdNQq7IYC*VYm(5IJ&RM" -AsPlainText -Force
        }
        "ad" {
            $AccountName = "AD.tullib.com\RT TPICAP PMS"
            $accontPassword = ConvertTo-SecureString -String "Xoe1A$XSpjIhEEKo1HX@S%Tm!bNNKiGN" -AsPlainText -Force
        }
        "apac" {
            $AccountName = "apac.ad.tullib.com\APAC PMS"
            $accontPassword = ConvertTo-SecureString -String "FwA48Ubmz@jDm3YzY7ZCLTf7)*J!#RrG" -AsPlainText -Force
        }
        "eur" {
            $AccountName = "EUR\EUR PMS"
            $accontPassword = ConvertTo-SecureString -String "2MWRnnoobQtUJ98VUh5EoYC7Qnm$J(H@" -AsPlainText -Force
        }
        "na" {
            $AccountName = "NA\NA PMS"
            $accontPassword = ConvertTo-SecureString -String "HI))QL^NbOjnd(Uz9Tk09@MMjbi@gIK%" -AsPlainText -Force
        }
        "au" {
            $AccountName = "au.icap.com\AU PMS"
            $accontPassword = ConvertTo-SecureString -String "Nx^L%8WP15Q(UJ(zIuRNY1QvsBI1)Kkz" -AsPlainText -Force
        }
        "br" {
            $AccountName = "br.icap.com\BR PMS"
            $accontPassword = ConvertTo-SecureString -String "G5jiZE(jv@AWhto" -AsPlainText -Force
        }
        "global" {
            $AccountName = "GLOBAL\GLOBAL PMS"
            $accontPassword = ConvertTo-SecureString -String "ry&Sw5p@P1ZY6sLFQxyK88ieQ#otXM(r" -AsPlainText -Force
        }
        "hk" {
            $AccountName = "HK\HK PMS"
            $accontPassword = ConvertTo-SecureString -String "$Nb%8kQ!UwEVN6rqy8CcxxrSNPGvocGH" -AsPlainText -Force
        }
        "jpn" {
            $AccountName = "JPN\JPN PMS"
            $accontPassword = ConvertTo-SecureString -String "vc2w6imvzCG*49d8e5Af7!^0mUubnAbW" -AsPlainText -Force
        }
        "uk" {
            $AccountName = "UK\UK PMS"
            $accontPassword = ConvertTo-SecureString -String "qc)52!AdzydT5sgBwo*nE9RP%gPIPHIA" -AsPlainText -Force
        }
        "us" {
            $AccountName = "US\US PMS"
            $accontPassword = ConvertTo-SecureString -String "JGkiIzX4uFzuR*wXosbO*U16NV^5JO6B" -AsPlainText -Force
        }
        "lnholdings" {
            $AccountName = "lnholdings.com\LN PMS"
            $accontPassword = ConvertTo-SecureString -String "v@m2c@qlh54zZfx%s%" -AsPlainText -Force
        }
        "icap" {
            $AccountName = "icap.com\RT ICAP PMS"
            $accontPassword = ConvertTo-SecureString -String "UDcB%rie@lqHGXM)0sk)^Hv48m*O)zN9" -AsPlainText -Force
        }
        "ebdev" {
            $AccountName = 'ebdev.tpebroking.com\EBDEV PMS'
            $accontPassword = ConvertTo-SecureString -String "ekcz0EItIqU0(uzLcUEn^h6a%5PkZ^cL" -AsPlainText -Force
        }
        "sg" {
            $AccountName = 'sg.icap.com\SG PMS'
            $accontPassword = ConvertTo-SecureString -String ')GGn#m@bP4$(RMk0KxXN%OPAfXBESyFt' -AsPlainText -Force
        }
    }
    $Creds = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $AccountName, $accontPassword

    return $creds
}

foreach($server in $servers) {

$credential = set-credential -computername $server
$cimSession = New-PSSession -ComputerName $server -Credential $credential

$userProfiles = Invoke-Command -Session $cimSession -ScriptBlock {
    Get-ChildItem -Path C:\Users | Where-Object { $_.PSIsContainer } | Select-Object -Property Name, LastWriteTime | Sort-Object LastWriteTime
}

$installedApps = Invoke-Command -Session $cimSession -ScriptBlock {
    Get-ItemProperty HKLM:\Software\Wow6432Node\Microsoft\Windows\CurrentVersion\Uninstall\* | 
    Select-Object DisplayName, DisplayVersion | Where-Object {$_.Displayname -ne $null}
    Sort-Object DisplayName
}

Remove-PSSession $cimSession

$Obj = New-Object -TypeName PSOBject
$Obj | Add-Member -MemberType NoteProperty -Name "ServerName" -Value $server
$Obj | Add-Member -MemberType NoteProperty -Name "UserProfile" -Value ($userProfiles.Name| Out-String).trim()
$Obj | Add-Member -MemberType NoteProperty -Name "LastWriteTime" -Value ($userProfiles.LastWriteTime | out-string).trim()
$Obj | Add-Member -MemberType NoteProperty -Name "Installed Apps" -Value ($installedApps.DisplayName | out-string).trim()
$Obj | Add-Member -MemberType NoteProperty -Name "Version" -Value ($installedapps.DisplayVersion | Out-String).trim()
$output += $Obj

}

$output | Format-Table -autosize -Wrap
$output | export-csv -Path 'C:\temp\CMDBinstalls.csv' -NoTypeInformation
